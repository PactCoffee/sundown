# Sundown

Sundown is a Zendesk App which looks up the ticket requester's email in Viper.

### Changelog
#### 1.0.0
* Display's the user's first and last name as a link to user's page the Viper Admin System
* Add PactCoffee icons
